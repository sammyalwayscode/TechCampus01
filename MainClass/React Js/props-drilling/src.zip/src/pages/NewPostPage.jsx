const NewPostPage = () => {
  return <div>NewPostPage</div>;
};

export default NewPostPage;
