const Footer = () => {
  return (
    <div>
      <p>This is the Footer</p>
    </div>
  );
};

export default Footer;
