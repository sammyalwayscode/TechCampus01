const Teacher = () => {
  return (
    <div>
      <h1>This is the Teacher Page</h1>
    </div>
  );
};

export default Teacher;
