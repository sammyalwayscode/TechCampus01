const Courses = () => {
  return (
    <div>
      <h1>This is the Coueses Page We are ready to learn</h1>
    </div>
  );
};

export default Courses;
