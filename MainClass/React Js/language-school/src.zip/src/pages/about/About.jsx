const About = () => {
  return (
    <div>
      <h1>This is the Abput Page</h1>
    </div>
  );
};

export default About;
