import "./BeLangComp.css";

const BeLangComp = () => {
  return <span className="heroTextCaption">BeLanguageSchool</span>;
};

export default BeLangComp;
