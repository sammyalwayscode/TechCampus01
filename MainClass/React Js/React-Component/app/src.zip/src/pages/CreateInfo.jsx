const CreateInfo = () => {
  return (
    <div>
      <h1>Create Info</h1>
    </div>
  );
};

export default CreateInfo;
