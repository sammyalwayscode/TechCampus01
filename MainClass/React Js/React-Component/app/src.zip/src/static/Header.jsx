const Header = () => {
  return (
    <div>
      <span>this is the header</span>
      <br />
      <br />
      <br />
    </div>
  );
};

export default Header;
