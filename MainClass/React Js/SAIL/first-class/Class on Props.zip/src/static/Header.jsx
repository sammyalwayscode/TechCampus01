import "./Header.css";

const Header = () => {
  return (
    <div className="container">
      <section>
        <h2>Social media Dashboard</h2>
      </section>
      <section>Dark mode</section>
    </div>
  );
};

export default Header;
