const HomeButtom = () => {
  return <div>HomeButtom</div>;
};

export default HomeButtom;
