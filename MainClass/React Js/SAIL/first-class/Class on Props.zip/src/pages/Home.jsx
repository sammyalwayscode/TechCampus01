import HomeButtom from "../components/home/HomeButtom";
import HomeTop from "../components/home/HomeTop";

const Home = () => {
  return (
    <div>
      <HomeTop />
      <HomeButtom />
    </div>
  );
};

export default Home;
